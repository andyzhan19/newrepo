package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
public class Main {


    public static void main(String[] args) {



        SpringApplication.run(Main.class, args);
    }
}