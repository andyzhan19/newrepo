package org.example;



import com.azure.data.appconfiguration.ConfigurationClient;
import com.azure.data.appconfiguration.ConfigurationClientBuilder;
import com.azure.data.appconfiguration.models.ConfigurationSetting;
import com.azure.identity.DefaultAzureCredentialBuilder;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class HelloController {

    @Value("${myapp.ttt}")
    private String message;

    @GetMapping("/xxx")
    public String hello() {
        log.info("testtes");
        return "Hello, Spring Boot!";
    }

    @GetMapping("/api")
    public ResponseEntity<String> test(HttpServletResponse response) {
        log.info(message);

        String connectionString = "Endpoint=https://rams-conf.azconfig.io;Id=f4WW;Secret=6A4HAT8I98Fq6W5D4woMWHIPhJSoj0nUj1Sw8uSncwzlXAb35tC5JQQJ99BFACYeBjFJvqhpAAACAZAC2XG0"; // From Azure Portal → Access Keys

        ConfigurationClient client = new ConfigurationClientBuilder()
                .connectionString(connectionString)
                .buildClient();

        System.out.println("Listing all key-values from Azure App Configuration:");

        for (ConfigurationSetting setting : client.listConfigurationSettings(null)) {
            System.out.printf("Key: %s, Value: %s%n", setting.getKey(), setting.getValue());
        }

//        ConfigurationClient client = new ConfigurationClientBuilder()
//                .endpoint("https://rams-conf.azconfig.io;Id=f4WW;Secret=6A4HAT8I98Fq6W5D4woMWHIPhJSoj0nUj1Sw8uSncwzlXAb35tC5JQQJ99BFACYeBjFJvqhpAAACAZAC2XG0")
//                .credential(new DefaultAzureCredentialBuilder().build())
//                .buildClient();
//
//        client.listConfigurationSettings(null).iterator().next();

       // response.setHeader("X-Trace-Id", "123abc");
        return ResponseEntity.ok("OK");
    }
}