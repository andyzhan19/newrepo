<script lang="ts">
  import Screen from "./ui/Screen.svelte";
</script>

<Screen />
