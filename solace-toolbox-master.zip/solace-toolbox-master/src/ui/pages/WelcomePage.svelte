<h1 class="text-2xl">Solace Toolbox</h1>
<p class="mt-2">
  This tool is a browser based mashup of <a href="https://github.com/jmstoolbox/jmstoolbox" class="text-blue-700"
    >JMSToolBox</a
  >
  and
  <a href="https://docs.solace.com/Solace-PubSub-Manager/PubSub-Manager-Overview.htm" class="text-blue-700"
    >PubSub+ Broker Manager</a
  > that lets you browse queues and create and run event simulators.
</p>
<h2 class="mt-4 text-xl">Links</h2>
<ul class="list-disc list-inside">
  <li>
    <a href="" class="text-blue-700">Project on GitHub</a>
  </li>
</ul>
