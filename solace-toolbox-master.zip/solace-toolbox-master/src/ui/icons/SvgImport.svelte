<svg xmlns="http://www.w3.org/2000/svg" fill="#000000" viewBox="0 0 256 256"
  ><rect width="256" height="256" fill="none" /><path
    d="M32,208V64a8,8,0,0,1,8-8H93.33333a8,8,0,0,1,4.8,1.6l27.73334,20.8a8,8,0,0,0,4.8,1.6H200a8,8,0,0,1,8,8v24"
    fill="none"
    stroke="currentColor"
    stroke-linecap="round"
    stroke-linejoin="round"
    stroke-width="16"
  /><path
    d="M32,208l30.17661-90.52982A8,8,0,0,1,69.76607,112H228.90059a8,8,0,0,1,7.58947,10.52982L208,208Z"
    fill="none"
    stroke="currentColor"
    stroke-linecap="round"
    stroke-linejoin="round"
    stroke-width="16"
  /></svg
>
